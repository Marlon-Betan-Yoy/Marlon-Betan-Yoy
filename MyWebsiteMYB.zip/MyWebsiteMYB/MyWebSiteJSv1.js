// File: MyWebSiteJSv1.js

// Use a functional init for future enhancements
const init = () => {
  console.log('Website loaded successfully.');
  // Example: you could add more interactivity here
};

// Run when DOM is ready
document.addEventListener('DOMContentLoaded', init);
